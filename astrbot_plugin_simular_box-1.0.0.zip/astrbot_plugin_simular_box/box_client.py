"""Small Streamable HTTP client for Simular shared boxes.

Tool calls are serialized because the remote shell and desktop share state.
An interrupted call is never replayed automatically.
"""

import asyncio
import json
import re
from dataclasses import dataclass, field
from urllib.parse import parse_qs, urlsplit

import aiohttp


class BoxError(Exception):
    """An error safe to show in chat, without credentials or request headers."""


@dataclass(frozen=True)
class BoxConnection:
    box_id: str
    key: str = field(repr=False)

    @property
    def url(self):
        return f"https://mcp.box.simular.ai/mcp/{self.box_id}"

    @classmethod
    def from_link(cls, link):
        text = str(link or "").strip().replace("\\&", "&").replace("https\\:", "https:")
        try:
            parts = urlsplit(text)
            valid_origin = (
                parts.scheme == "https"
                and parts.hostname == "box.simular.ai"
                and parts.port in (None, 443)
                and not parts.username
                and not parts.password
                and parts.path.rstrip("/") == "/s"
            )
        except ValueError:
            valid_origin = False
        if not valid_origin:
            raise BoxError(
                "请在插件配置中填写完整的 https://box.simular.ai/s#box=…&key=… 共享链接。"
            )
        values = parse_qs(parts.fragment)
        box_ids, keys = values.get("box", []), values.get("key", [])
        if (
            len(box_ids) != 1
            or len(keys) != 1
            or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", box_ids[0])
            or not re.fullmatch(r"cbs_[0-9a-f]{32}", keys[0])
        ):
            raise BoxError("共享链接不完整，请保留 # 后面的 box 和 key 两项。")
        return cls(box_ids[0], keys[0])

    def redact(self, text):
        return str(text).replace(self.key, "[密钥已隐藏]")


class BoxClient:
    MAX_RESPONSE_BYTES = 16 * 1024 * 1024
    PROTOCOL = "2025-03-26"

    def __init__(self, connection, connect_timeout=20, call_timeout=60):
        self.connection = connection
        self.connect_timeout = connect_timeout
        self.call_timeout = call_timeout
        self._http = None
        self._session_id = None
        self._initialized = False
        self._closed = False
        self._counter = 0
        self._lock = asyncio.Lock()
        self._tools = None
        self.server_info = {}
        self.instructions = ""

    def _headers(self):
        headers = {
            "Authorization": f"Bearer {self.connection.key}",
            "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": self.PROTOCOL,
        }
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id
        return headers

    def _http_session(self):
        if self._closed:
            raise BoxError("插件正在关闭，请稍后再试。")
        if self._http is None or self._http.closed:
            self._http = aiohttp.ClientSession(trust_env=False)
        return self._http

    async def _read_reply(self, response, expected_id):
        """Read JSON or an SSE reply, including notifications and large images."""
        is_sse = "text/event-stream" in response.headers.get("Content-Type", "")
        buffer = b""
        data_lines = []
        byte_count = 0
        async for chunk in response.content.iter_any():
            byte_count += len(chunk)
            if byte_count > self.MAX_RESPONSE_BYTES:
                raise BoxError("box 返回内容超过 16 MB，请缩小截图或分段读取。")
            buffer += chunk
            if not is_sse:
                continue
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                line = line.rstrip(b"\r")
                if line.startswith(b"data:"):
                    data_lines.append(line[5:].lstrip(b" "))
                elif not line and data_lines:
                    reply = json.loads(b"\n".join(data_lines))
                    data_lines = []
                    if isinstance(reply, dict) and reply.get("id") == expected_id:
                        return reply
        if not is_sse:
            reply = json.loads(buffer)
            if isinstance(reply, dict) and reply.get("id") == expected_id:
                return reply
        raise BoxError("box 没有返回本次请求的结果；请先检查机器状态。")

    async def _rpc(self, method, params=None, timeout=None, notification=False):
        self._counter += 1
        payload = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        if not notification:
            payload["id"] = self._counter
        try:
            async with self._http_session().post(
                self.connection.url,
                headers=self._headers(),
                json=payload,
                timeout=aiohttp.ClientTimeout(total=timeout or self.call_timeout),
                allow_redirects=False,
            ) as response:
                if response.status in (401, 403):
                    self._initialized = False
                    self._session_id = None
                    raise BoxError(
                        "共享权限不可用：请检查链接是否过期或撤销，以及是否允许 AI 操作。"
                    )
                if response.status == 404:
                    self._initialized = False
                    self._session_id = None
                    self._tools = None
                    raise BoxError(
                        "box 或连接会话已失效。本次操作没有自动重试，请先检查状态。"
                    )
                if response.status not in (200, 202):
                    raise BoxError(f"box 连接失败（HTTP {response.status}）。")
                if method == "initialize":
                    self._session_id = response.headers.get("Mcp-Session-Id")
                if notification:
                    return {}
                reply = await self._read_reply(response, payload["id"])
        except asyncio.CancelledError:
            self._initialized = False
            self._session_id = None
            raise
        except (TimeoutError, aiohttp.ClientError):
            self._initialized = False
            self._session_id = None
            raise BoxError(
                "box 连接中断或超时，操作结果尚不确定。没有自动重试；请先检查页面或文件状态。"
            ) from None
        except (ValueError, UnicodeError):
            raise BoxError("box 返回的内容无法解析，请检查服务状态。") from None
        if "error" in reply:
            error = reply["error"]
            message = self.connection.redact(error.get("message", "请求失败"))[:500]
            raise BoxError(f"box：{message}")
        if "result" not in reply:
            raise BoxError("box 返回了缺少结果的响应。")
        return reply["result"]

    async def _ensure_initialized(self):
        if self._initialized:
            return
        self._tools = None
        result = await self._rpc(
            "initialize",
            {
                "protocolVersion": self.PROTOCOL,
                "capabilities": {},
                "clientInfo": {
                    "name": "astrbot-plugin-simular-box",
                    "version": "1.0.0",
                },
            },
            timeout=self.connect_timeout,
        )
        if result.get("protocolVersion") != self.PROTOCOL:
            raise BoxError("box 返回了不支持的协议版本。")
        self.server_info = result.get("serverInfo", {})
        self.instructions = result.get("instructions", "")
        await self._rpc(
            "notifications/initialized", notification=True, timeout=self.connect_timeout
        )
        self._initialized = True

    async def _list_tools(self, refresh=False):
        await self._ensure_initialized()
        if self._tools is not None and not refresh:
            return self._tools
        tools, cursor, seen = [], None, set()
        for _ in range(20):
            params = {"cursor": cursor} if cursor else {}
            result = await self._rpc("tools/list", params, timeout=self.connect_timeout)
            tools.extend(result.get("tools", []))
            cursor = result.get("nextCursor")
            if not cursor:
                self._tools = tools
                return tools
            if cursor in seen:
                break
            seen.add(cursor)
        raise BoxError("工具列表分页异常，请检查 box 服务。")

    async def list_tools(self, refresh=False):
        async with self._lock:
            return await self._list_tools(refresh)

    async def call_tool(self, name, arguments):
        if not isinstance(arguments, dict):
            raise BoxError("工具参数必须是 JSON 对象。")
        async with self._lock:
            tools = await self._list_tools()
            if name not in {tool.get("name") for tool in tools}:
                raise BoxError(
                    "找不到该 box 工具，请先调用 box_tools 获取最新名称与参数。"
                )
            return await self._rpc("tools/call", {"name": name, "arguments": arguments})

    async def close(self):
        async with self._lock:
            self._closed = True
            if self._http is not None and not self._http.closed:
                if self._session_id:
                    try:
                        async with self._http.delete(
                            self.connection.url,
                            headers=self._headers(),
                            timeout=aiohttp.ClientTimeout(total=5),
                            allow_redirects=False,
                        ):
                            pass
                    except (TimeoutError, aiohttp.ClientError):
                        pass
                await self._http.close()
            self._session_id = None
            self._initialized = False
