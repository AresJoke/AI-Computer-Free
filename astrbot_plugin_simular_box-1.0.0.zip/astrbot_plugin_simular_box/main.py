"""AstrBot tools and commands for a Simular shared cloud desktop."""

import asyncio
import base64
import json
import uuid

from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star, StarTools
from mcp.types import CallToolResult, TextContent

from .box_client import BoxClient, BoxConnection, BoxError


def bounded_int(value, default, low, high):
    try:
        return max(low, min(high, int(value)))
    except (TypeError, ValueError):
        return default


class SimularBoxPlugin(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context)
        self.config = config if config is not None else {}
        self._client = None
        self._client_lock = asyncio.Lock()
        self._closed = False

    def _authorize(self, event):
        if self._closed:
            raise BoxError("插件正在关闭，请稍后再试。")
        if self.config.get("enabled", True) is not True:
            raise BoxError("box 插件已在配置中关闭。")
        if event.is_admin():
            return
        # Entries identify a platform instance as well as the sender, avoiding
        # accidental permission sharing between different bot connections.
        platform_id = event.get_platform_id()
        sender_id = event.get_sender_id()
        identity = f"{platform_id}:{sender_id}"
        allowed = self.config.get("allowed_users", [])
        if (
            isinstance(allowed, list)
            and platform_id
            and sender_id
            and identity in allowed
        ):
            return
        raise BoxError("box 仅允许 AstrBot 管理员或插件配置中授权的用户使用。")

    async def _get_client(self):
        connection = BoxConnection.from_link(self.config.get("shared_link", ""))
        async with self._client_lock:
            if self._closed:
                raise BoxError("插件正在关闭，请稍后再试。")
            if self._client is None or self._client.connection != connection:
                if self._client is not None:
                    await self._client.close()
                self._client = BoxClient(
                    connection,
                    connect_timeout=bounded_int(
                        self.config.get("connect_timeout"), 20, 5, 60
                    ),
                    call_timeout=bounded_int(
                        self.config.get("call_timeout"), 60, 10, 300
                    ),
                )
            return self._client

    def _error_result(self, message):
        return CallToolResult(
            isError=True, content=[TextContent(type="text", text=str(message))]
        )

    def _limit_result(self, client, raw):
        limit = bounded_int(self.config.get("max_output_chars"), 24000, 1000, 100000)
        remaining = limit
        result = dict(raw)
        content = []
        for original in raw.get("content", []):
            item = dict(original)
            if item.get("type") == "text":
                text = client.connection.redact(item.get("text", ""))
                item["text"] = text[:remaining]
                if len(text) > remaining:
                    item["text"] += "\n[输出已截断，请分段读取。]"
                remaining = max(0, remaining - len(text))
            content.append(item)
        result["content"] = content
        return CallToolResult.model_validate(result)

    async def _invoke(self, event, name, arguments):
        try:
            self._authorize(event)
            if not isinstance(arguments, dict):
                raise BoxError("arguments 必须是 JSON 对象。")
            if name == "shell":
                arguments = dict(arguments)
                # Leave time for the remote timeout error to reach AstrBot.
                max_timeout = (
                    bounded_int(self.config.get("call_timeout"), 60, 10, 300) - 5
                )
                arguments["timeout_s"] = bounded_int(
                    arguments.get("timeout_s"), 30, 1, max_timeout
                )
            client = await self._get_client()
            raw = await client.call_tool(name, arguments)
            return self._limit_result(client, raw)
        except BoxError as exc:
            return self._error_result(str(exc))
        except (ValueError, TypeError):
            return self._error_result("box 返回内容或参数格式不正确，请检查工具说明。")

    @filter.llm_tool(name="box_tools")
    async def box_tools(self, event: AstrMessageEvent, name: str = ""):
        """查看 Simular box 云电脑的工具名称、用途及真实参数格式。

        操作浏览器、桌面或文件前，传入工具名称获取其完整 JSON Schema；留空列出全部工具。
        这里的 box 是 Simular 云电脑，任务在远程 Ubuntu 上执行。

        Args:
            name(string): 工具名称，例如 browser_navigate、computer_act、gui_plan；留空列出名称与用途。
        """
        try:
            self._authorize(event)
            client = await self._get_client()
            tools = await client.list_tools(refresh=True)
            if name:
                selected = [tool for tool in tools if tool.get("name") == name]
                if not selected:
                    raise BoxError("找不到该工具，请将 name 留空获取工具列表。")
                return json.dumps(selected[0], ensure_ascii=False)
            return json.dumps(
                {
                    "box_id": client.connection.box_id,
                    "instructions": client.instructions,
                    "tools": [
                        {"name": t["name"], "description": t.get("description", "")}
                        for t in tools
                    ],
                    "next_step": "用 box_tools(name=工具名称) 获取参数，再用 box_call 调用。shell 可直接用 box_shell。",
                },
                ensure_ascii=False,
            )
        except BoxError as exc:
            return self._error_result(str(exc))

    @filter.llm_tool(name="box_call")
    async def box_call(self, event: AstrMessageEvent, name: str, arguments: dict):
        """调用 Simular 云电脑的浏览器、桌面或文件工具；先用 box_tools 查询该工具的参数。

        返回的截图供支持视觉的模型查看。执行结果来自 box，不能把本机文件路径当作远程文件。
        超时表示结果不确定，先检查状态；不要重复执行可能已完成的点击、提交或写入。

        Args:
            name(string): box_tools 返回的原始工具名称，如 browser_navigate 或 gui_plan。
            arguments(object): 严格按该工具 JSON Schema 填写的参数对象，不是 JSON 字符串。
        """
        return await self._invoke(event, name, arguments)

    @filter.llm_tool(name="box_shell")
    async def box_shell(
        self, event: AstrMessageEvent, command: str, timeout_s: int = 30
    ):
        """在 Simular box 的持久化 Bash 会话执行命令，初始目录 /workspace。

        适合运行 Python、Node.js、Git 和处理远程文件。浏览器交互用 box_call。
        相对路径指向云电脑；长任务请保存结果并后台执行，随后检查状态。

        Args:
            command(string): Bash 命令或脚本。
            timeout_s(number): 远程等待秒数，默认 30，会限制在插件调用超时以内。
        """
        return await self._invoke(
            event, "shell", {"command": command, "timeout_s": timeout_s}
        )

    @filter.llm_tool(name="box_screenshot")
    async def box_screenshot(self, event: AstrMessageEvent):
        """查看 Simular box 当前桌面截图，供支持视觉的模型判断页面状态。

        点击坐标应对应最近截图。需要把截图发给用户时，使用 /box 截图 命令。
        """
        return await self._invoke(event, "screenshot", {"max_edge": 1024})

    @filter.command("box")
    async def box_command(self, event: AstrMessageEvent, action: str = "help"):
        try:
            self._authorize(event)
            action = action.strip().lower()
            if action in ("help", "帮助"):
                yield event.plain_result(
                    "Simular box 云电脑\n/box 状态：检查连接\n/box 工具：工具列表\n"
                    "/box 截图：发送桌面截图\n/box 身份：查看授权标识\n"
                    "也可以直接说：用 box 打开 Chrome 搜索 Simular；用 box 运行 Python。"
                )
                return
            if action in ("identity", "身份"):
                yield event.plain_result(
                    f"授权标识：{event.get_platform_id()}:{event.get_sender_id()}"
                )
                return
            client = await self._get_client()
            if action in ("status", "状态"):
                tools = await client.list_tools(refresh=True)
                yield event.plain_result(
                    f"box 连接正常：{client.connection.box_id}\n已发现 {len(tools)} 个工具。\n"
                    "执行权限由共享链接的设置决定；本插件仅允许管理员或已授权用户调用。"
                )
            elif action in ("tools", "工具"):
                tools = await client.list_tools(refresh=True)
                yield event.plain_result(
                    "box 工具：\n" + "\n".join(t["name"] for t in tools)
                )
            elif action in ("screenshot", "截图"):
                result = await self._invoke(event, "screenshot", {"max_edge": 1280})
                images = [c for c in result.content if c.type == "image"]
                if not images:
                    text = "\n".join(c.text for c in result.content if c.type == "text")
                    yield event.plain_result(text[:3000] or "box 没有返回截图。")
                    return
                folder = (
                    StarTools.get_data_dir("astrbot_plugin_simular_box") / "screenshots"
                )
                folder.mkdir(parents=True, exist_ok=True)
                for image in images[:2]:
                    extension = {
                        "image/png": ".png",
                        "image/jpeg": ".jpg",
                        "image/webp": ".webp",
                    }.get(image.mimeType)
                    if not extension:
                        raise BoxError("box 返回了不支持的截图格式。")
                    path = folder / ("box_" + uuid.uuid4().hex + extension)
                    path.write_bytes(base64.b64decode(image.data, validate=True))
                    yield event.image_result(str(path))
                # The directory is owned by this plugin; keep the latest 64.
                saved = sorted(
                    folder.glob("box_*.*"),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                )
                for old in saved[64:]:
                    old.unlink(missing_ok=True)
            else:
                yield event.plain_result("未知命令，请用 /box 帮助 查看用法。")
        except BoxError as exc:
            yield event.plain_result(str(exc))
        except (OSError, ValueError):
            yield event.plain_result("截图无法保存，请检查插件数据目录和返回格式。")

    async def terminate(self):
        async with self._client_lock:
            self._closed = True
            if self._client is not None:
                await self._client.close()
                self._client = None
