"""Simular box plugin package."""
